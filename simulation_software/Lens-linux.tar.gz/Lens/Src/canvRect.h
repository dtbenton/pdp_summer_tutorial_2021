#ifndef CANVRECT_H
#define CANVRECT_H

extern void createCanvRectType(void);

#endif

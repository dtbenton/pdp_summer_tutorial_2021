This directory contains a precompiled version of Lens that runs under Mac OS X
(64-bit).  Here is what you have to do to be able to run the binaries (lens
and alens).

1) Open a Terminal and run "which X".  If it returns a full pathname
(something like "/opt/X11/bin/X") you can skip this step.  Otherwise, 
you'll need to install an X-windows server.  To do this, download the latest
version of XQuartz from

  https://www.xquartz/org

or download

  http://www.cnbc.cmu.edu/~plaut/Lens/XQuartz-2.7.11.dmg

Double-click the dmg file to open it, and then double-click XQuartz.pkg to run
the installer.  When it finishes, you'll need to log out and log back in (as
prompted).  [Note - just exiting and restarting the terminal is not enough; if
you get an error message about DISPLAY being undefined, you need to log out
and log back in.]

2) If the "Lens" folder is not on your desktop, edit bash_profile.txt and
modify the setting for LENSDIR to correspond to its location.  Be sure to save
the file as a plain text file.

3) Open a Terminal, navigate to your Lens folder (e.g., "cd Desktop/Lens"), and
run the following two commands:

   source bash_profile.txt
   cat bash_profile.txt >> ~/.bash_profile

The first modifies the current terminal; the second modifies a start-up script
so the settings will be present whenever you open a Terminal.

4) If you run "which lens" in the Terminal, it should say something like

   /Users/plaut/Desktop/Lens/Bin/x86_64/lens

If it says nothing, something has gone wrong.....:-(

RUNNING LENS

In general, to run Lens, open a Terminal, use the "cd" command to navigate to
the folder containing your Lens script files, and run "lens" (or run "lens
network.in" if network.in is the name of your script).

You can also run Lens by double-clicking on the lens executable in
Lens/Bin/x86_64/.  In this case, Lens will open its own terminal along with
the main console.  To open a script, you'll have to navigate to the
appropriate folder using the directory/file window in Lens.

An offline version of the Lens manual can be read by pointing your browser at
Lens/Manual/index.html.

David Plaut
plaut@cmu.edu
5 Jan 2017

I: (task) 1 0 0 (input) 0 0 0 1 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 0 0 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 0 0 1 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 0 1 0
T: 0 0;
I: (task) 0 0 1 (input) 0 1 0 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 0 1 1 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 1 1
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 1 0 1 1 1 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 1 1 1
T: 1 1;
I: (task) 0 0 1 (input) 1 0 1 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 1 1 1 1 1 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 1 1 1
T: 1 1;
I: (task) 0 0 1 (input) 1 1 1 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 1 0 1 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 1 1
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 1 0 1 0 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 0 1
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 1 0 0 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 1 1 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 1 0 1 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 1 1
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 1 0 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 0 0
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 1 0 1 0 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 0 1
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 1 0 0 1 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 0 1 0
T: 0 0;
I: (task) 0 0 1 (input) 1 1 0 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 1 1 0 1 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 1 1 0 0 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 0 0 0
T: 1 0;
I: (task) 0 0 1 (input) 1 1 1 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 0 0 1 0 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 1 0 1
T: 0 1;
I: (task) 0 0 1 (input) 1 0 0 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 1 0 1 1 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 1 1 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 1 1 0 0 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 1 1 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 0 0 0 1 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 0 1 0
T: 0 0;
I: (task) 0 0 1 (input) 0 0 0 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 1 0 1 1 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 1 1 0
T: 0 1;
I: (task) 0 0 1 (input) 1 1 0 1 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 0 0 0 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 1 0 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 0 1 1 1 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 1 0
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 1 1 0 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 1 0 1
T: 1 1;
I: (task) 0 0 1 (input) 1 0 1 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 0 0 0 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 0 1 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 1 1 1 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 1 0 1
T: 1 1;
I: (task) 0 0 1 (input) 1 1 1 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 1 0 1 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 1 0 1 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 1 0 1
T: 0 1;
I: (task) 0 0 1 (input) 1 1 0 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 0 1 1 0 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 1 0 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 0 0 1 0 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 1 0 0
T: 0 1;
I: (task) 0 0 1 (input) 1 0 0 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 0 1 1 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 1 1 0
T: 0 1;
I: (task) 0 0 1 (input) 1 1 0 1 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 1 1 0 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 1 0 1
T: 1 1;
I: (task) 0 0 1 (input) 1 0 1 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 0 1 1 0 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 0 1
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 0 0 1 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 0 0 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 0 0 0 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 0 1 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 0 0 0 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 0 1 1
T: 0 0;
I: (task) 0 0 1 (input) 0 0 0 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 0 1 0 1 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 0 0 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 1 1 0 1 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 1 1 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 0 1 1 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 1 0 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 0 0 0 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 0 0 0
T: 0 0;
I: (task) 0 0 1 (input) 1 1 0 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 0 1 1 1 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 1 1 1
T: 1 1;
I: (task) 0 0 1 (input) 1 0 1 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 1 1 1 0 0 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 0 0 0
T: 1 0;
I: (task) 0 0 1 (input) 1 1 1 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 0 1 1 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 1 1 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 0 1 1 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 1 0
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 0 0 0 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 0 1 1
T: 0 0;
I: (task) 0 0 1 (input) 0 0 0 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 0 1 0 1 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 0 0 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 0 0 0 0 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 0 0 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 1 0 0 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 1 1 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 1 1 1 1 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 1 1 0
T: 1 1;
I: (task) 0 0 1 (input) 1 1 1 1 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 1 1 0 1 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 1 1 1 0 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 1 0 1
T: 1 1;
I: (task) 0 0 1 (input) 0 1 1 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 0 0 0 0 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 1 0 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 0 0 1 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 0 0 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 1 1 0 0 1 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 0 1 0
T: 0 0;
I: (task) 0 0 1 (input) 1 1 0 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 0 1 1 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 1 1 0
T: 0 1;
I: (task) 0 0 1 (input) 1 0 0 1 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 1 1 0 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 0 0
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 0 0 0 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 0 1 1
T: 0 0;
I: (task) 0 0 1 (input) 0 0 0 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 0 1 1 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 1 1
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 0 1 0 0 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 0 0 0
T: 1 0;
I: (task) 0 0 1 (input) 0 0 1 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 1 0 1 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 1 1 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 1 1 0 1 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 0 1 1
T: 1 0;
I: (task) 0 0 1 (input) 1 1 1 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 0 0 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 0 0 0
T: 0 0;
I: (task) 0 0 1 (input) 0 1 0 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 0 1 1 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 1 1 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 1 0 0 1 0 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 1 0 0
T: 0 1;
I: (task) 0 0 1 (input) 1 0 0 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 1 1 0 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 1 1 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 1 0 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 0 0 1
T: 1 0;
I: (task) 0 0 1 (input) 1 1 1 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 1 0 0 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 0 1
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 1 1 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 0 1 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 0 1 1 0 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 1 0 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 1 1 0 0
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 1 1 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 0 1 0 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 0 1 1
T: 1 0;
I: (task) 0 0 1 (input) 0 0 1 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 0 1 0 1 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 0 0 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 0 1 0 0 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 0 0 1
T: 1 0;
I: (task) 0 0 1 (input) 0 0 1 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 1 0 1 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 1 1
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 1 1 0 0 1 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 0 1 1
T: 0 0;
I: (task) 0 0 1 (input) 1 1 0 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 1 0 0 1 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 0 1 1
T: 0 0;
I: (task) 0 0 1 (input) 0 1 0 0 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 0 0 1 0 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 1 0 1
T: 0 1;
I: (task) 0 0 1 (input) 0 0 0 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 0 0 1 1 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 1 0 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 1 0 1 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 0 0 1 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 0 1 0
T: 0 0;
I: (task) 0 0 1 (input) 1 0 0 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 0 1 0 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 1 0 1
T: 0 1;
I: (task) 0 0 1 (input) 1 0 0 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 0 1 1 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 1 1
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 1 1 0 1
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 1 0 1
T: 1 1;
I: (task) 0 0 1 (input) 0 1 1 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 1 1 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 0 1 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 1 0 1 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 0 1 0 1
T: 0 1;
I: (task) 0 0 1 (input) 1 1 0 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 1 1 1 0 1
T: 1 1;
I: (task) 0 1 0 (input) 1 1 1 1 0 1
T: 1 1;
I: (task) 0 0 1 (input) 1 1 1 1 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 1 1 1 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 1 0 0
T: 1 1;
I: (task) 0 0 1 (input) 0 1 1 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 0 0 0 0 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 0 0 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 1 0 1 0 0 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 0 0 0
T: 1 0;
I: (task) 0 0 1 (input) 1 0 1 0 0 0
T: 0 0;
I: (task) 1 0 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 0 1 0 0
T: 0 1;
I: (task) 0 0 1 (input) 0 1 0 1 0 0
T: 0 0;
I: (task) 1 0 0 (input) 1 0 1 0 1 0
T: 1 0;
I: (task) 0 1 0 (input) 1 0 1 0 1 0
T: 1 0;
I: (task) 0 0 1 (input) 1 0 1 0 1 0
T: 1 0;
I: (task) 1 0 0 (input) 1 0 0 0 0 1
T: 1 0;
I: (task) 0 1 0 (input) 1 0 0 0 0 1
T: 0 0;
I: (task) 0 0 1 (input) 1 0 0 0 0 1
T: 0 1;
I: (task) 1 0 0 (input) 0 0 1 1 1 1
T: 0 0;
I: (task) 0 1 0 (input) 0 0 1 1 1 1
T: 1 1;
I: (task) 0 0 1 (input) 0 0 1 1 1 1
T: 1 1;
I: (task) 1 0 0 (input) 0 1 1 1 1 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 1 1 0
T: 1 1;
I: (task) 0 0 1 (input) 0 1 1 1 1 0
T: 1 0;
I: (task) 1 0 0 (input) 0 1 1 0 0 0
T: 0 1;
I: (task) 0 1 0 (input) 0 1 1 0 0 0
T: 1 0;
I: (task) 0 0 1 (input) 0 1 1 0 0 0
T: 0 0;

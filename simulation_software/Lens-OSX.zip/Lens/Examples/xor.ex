;
# Here is the file in sparse format:
;
i:1 t:0;
i:0 t:0;
i:*;

# This would be the file in dense format:
#I:0 0 T:0;
#I:0 1 T:1;
#I:1 0 T:1;
#I:1 1 T:0;

name:{A A 1 2 1 2}
6
i:0 t:{-} *
i:0 t:{-} *
i: t:0
i: t:1
i: t:0
i: t:1
;
name:{A B 1 2 2 3}
6
i:0 t:{-} *
i:1 t:{-} *
i: t:0
i: t:1
i: t:1
i: t:2
;
name:{A C 1 2 3 1}
6
i:0 t:{-} *
i:2 t:{-} *
i: t:0
i: t:1
i: t:2
i: t:0
;
name:{A E 1 2 1 3}
6
i:0 t:{-} *
i:4 t:{-} *
i: t:0
i: t:1
i: t:0
i: t:2
;
name:{B A 2 3 1 2}
6
i:1 t:{-} *
i:0 t:{-} *
i: t:1
i: t:2
i: t:0
i: t:1
;
name:{B B 2 3 2 3}
6
i:1 t:{-} *
i:1 t:{-} *
i: t:1
i: t:2
i: t:1
i: t:2
;
name:{B C 2 3 3 1}
6
i:1 t:{-} *
i:2 t:{-} *
i: t:1
i: t:2
i: t:2
i: t:0
;
name:{B D 2 3 2 1}
6
i:1 t:{-} *
i:3 t:{-} *
i: t:1
i: t:2
i: t:1
i: t:0
;
name:{C B 3 1 2 3}
6
i:2 t:{-} *
i:1 t:{-} *
i: t:2
i: t:0
i: t:1
i: t:2
;
name:{C C 3 1 3 1}
6
i:2 t:{-} *
i:2 t:{-} *
i: t:2
i: t:0
i: t:2
i: t:0
;
name:{C D 3 1 2 1}
6
i:2 t:{-} *
i:3 t:{-} *
i: t:2
i: t:0
i: t:1
i: t:0
;
name:{C E 3 1 1 3}
6
i:2 t:{-} *
i:4 t:{-} *
i: t:2
i: t:0
i: t:0
i: t:2
;
name:{D A 2 1 1 2}
6
i:3 t:{-} *
i:0 t:{-} *
i: t:1
i: t:0
i: t:0
i: t:1
;
name:{D C 2 1 3 1}
6
i:3 t:{-} *
i:2 t:{-} *
i: t:1
i: t:0
i: t:2
i: t:0
;
name:{D D 2 1 2 1}
6
i:3 t:{-} *
i:3 t:{-} *
i: t:1
i: t:0
i: t:1
i: t:0
;
name:{D E 2 1 1 3}
6
i:3 t:{-} *
i:4 t:{-} *
i: t:1
i: t:0
i: t:0
i: t:2
;
name:{E A 1 3 1 2}
6
i:4 t:{-} *
i:0 t:{-} *
i: t:0
i: t:2
i: t:0
i: t:1
;
name:{E B 1 3 2 3}
6
i:4 t:{-} *
i:1 t:{-} *
i: t:0
i: t:2
i: t:1
i: t:2
;
name:{E D 1 3 2 1}
6
i:4 t:{-} *
i:3 t:{-} *
i: t:0
i: t:2
i: t:1
i: t:0
;
name:{E E 1 3 1 3}
6
i:4 t:{-} *
i:4 t:{-} *
i: t:0
i: t:2
i: t:0
i: t:2
;

defI: -
;

name: "desk (office)"
i: 9
;

name: "oven (kitchen)"
i: 39
;

name: "sofa (living room)"
i: 20
;

name: "bed (bedroom)"
i: 11
;

name: "bathtub (bathroom)"
i: 34
;

name: "empty"
i: {-} *
;

name: "office (prototype)"
I: 1 1 1 -1 -1 1 -1 -1 -1 1 1 -1 1 1 1 1 1 -1 1 -1 -1 -1 1 1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 1 -1 
;

name: "kitchen (prototype)"
I: 1 1 -1 1 -1 -1 -1 1 -1 -1 1 -1 -1 -1 -1 -1 -1 1 -1 -1 -1 -1 1 -1 -1 1 1 1 1 1 1 1 -1 -1 -1 -1 -1 -1 -1 1 
;
name: "living room (prototype)"
I: 1 1 1 1 1 -1 -1 -1 -1 -1 1 -1 -1 1 1 1 -1 1 1 1 1 1 -1 -1 1 1 -1 -1 -1 -1 -1 -1 -1 1 -1 -1 -1 -1 -1 -1 
;

name: "bedroom (prototype)"
I: 1 1 1 1 -1 -1 1 -1 -1 -1 -1 1 -1 1 1 1 -1 1 1 -1 -1 -1 -1 -1 -1 1 -1 -1 -1 -1 -1 -1 1 1 -1 -1 -1 1 -1 -1 
;

name: "bathroom (prototype)"
I: 1 1 1 -1 -1 -1 -1 -1 1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 1 -1 -1 1 -1 -1 -1 1 1 1 -1 -1 -1 
;
